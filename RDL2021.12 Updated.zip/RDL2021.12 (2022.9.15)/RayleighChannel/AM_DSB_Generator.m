%  Signal Processing [SP]
%  Generate AM-DSB modulated signals with rayleigh channel and mixed noise
%  File: AM-DSB_Generator.m created by MATLAB 2019a
%  Last Revised: v 1.0    Date: 2021/12/05
%  Created: 2021/12/05
%  Author:  Shengyang Luan
%  Email:  luan@jsnu.edu.cn
%  (C)  School of Electrical Engineering and Automation
%       Jiangsu Normal University

function SNC_AM_DSB = AM_DSB_Generator(fc,fs,T,GSNR,alpha,cycle)
tic
%% Basic Parameters
signal.length_used = 1024;
signal.fs          = fs;      % Sampling frequency
signal.fc          = fc;      % Carrier frequency
signal.duration    = T;       % Signal duration
noise.gsnr         = GSNR;    % Generalized signal-to-noise ratio
noise.alpha        = alpha;   % Characteristic exponent
iter.cycle         = cycle;   % Number of samples

signal.dt          = 1/signal.fs; 
signal.N           = signal.duration/ signal.dt;
signal.t           = 0: signal.dt: signal.duration-signal.dt; 
signal.noise_cycle = zeros(iter.cycle,1024); 

for cnt = 1:iter.cycle
    
    %% Baseband Signal Generation
    signal.baseband =   5 + unifrnd(-5,5,1,signal.N);
    %% Passband Signal Generation
    signal.passband  = modulate(signal.baseband, signal.fc, 1/signal.dt,'amdsb-tc');
    
    signal.passband_c = hilbert(signal.passband).*exp(-1i*2 *pi *signal.fc *signal.t); 

    signal.passband_used = signal.passband_c(1:signal.length_used);  

    rayleighchan = comm.RayleighChannel(...
        'SampleRate',signal.fs, ... 
        'PathDelays',[0 1e-4], ... 
        'AveragePathGains',[0 -3], ... 
        'NormalizePathGains',true, ...
        'MaximumDopplerShift',50);     
    signal.passband_RayleighChannel = rayleighchan(signal.passband_used'); 
    
    signal.R_Sig = real(signal.passband_RayleighChannel);
    signal.R_Sig_P = mean(signal.R_Sig.^2);  
    
    signal.I_Sig = imag(signal.passband_RayleighChannel);
    signal.I_Sig_P = mean(signal.I_Sig.^2);  
    %% Gaussian Noise and Alpha-stable Noise
    % REAL
    signal.R_Sig_Gnoise = awgn(signal.R_Sig, noise.gsnr, 'measured');
    noise.R_Gnoise = signal.R_Sig_Gnoise - signal.R_Sig;
    noise.R_Gnoise_P = mean(noise.R_Gnoise.^2);  
    
    noise.beta = 0;  
    noise.delta = 0;
    noise.R_gamma = noise.R_Gnoise_P;  
%     noise.R_gamma = ( signal.R_Sig_P / 10^(noise.gsnr/10) )^(1/noise.alpha);
    noise.R_Anoise = Func_StableRnd(noise.alpha, noise.beta, noise.R_gamma, noise.delta, 1,signal.length_used); 
    
    % IMAG
    signal.I_Sig_Gnoise = awgn(signal.I_Sig, noise.gsnr, 'measured'); 
    noise.I_Gnoise = signal.I_Sig_Gnoise - signal.I_Sig; 
    noise.I_Gnoise_P = mean(noise.I_Gnoise.^2); 
    
    noise.I_gamma = noise.I_Gnoise_P;  
%     noise.I_gamma = ( signal.I_Sig_P / 10^(noise.gsnr/10) )^(1/noise.alpha);
    noise.I_Anoise = Func_StableRnd(noise.alpha, noise.beta, noise.I_gamma, noise.delta, 1,signal.length_used);  
    
    %% Add Noise
    noise.R_signal = signal.R_Sig + noise.R_Gnoise + noise.R_Anoise';
    noise.I_signal = signal.I_Sig + noise.I_Gnoise + noise.I_Anoise';
    
    noise.signal = noise.R_signal + 1i*noise.I_signal;
    %%
    signal.noise_cycle(cnt,:) = noise.signal';
end
SNC_AM_DSB = signal.noise_cycle;
save(['./signal/AM_DSB alpha = ',num2str(noise.alpha*10),' GSNR = ',num2str(noise.gsnr),'.mat'],'SNC_AM_DSB');

toc