%  Signal Processing [SP]
%  Generate PAM4 modulated signals with rician channel and mixed noise
%  File: PAM4_Generator.m created by MATLAB 2019a
%  Last Revised: v 1.0    Date: 2021/12/05
%  Created: 2021/12/05
%  Author:  Shengyang Luan
%  Email:  luan@jsnu.edu.cn
%  (C)  School of Electrical Engineering and Automation
%       Jiangsu Normal University

function SNC_PAM4 = PAM4_Generator(fc,fs,Baud,T,M,GSNR,alpha,cycle)
%% Timer
tic
%% Basic Parameters
signal.length_used = 1024;
signal.fs          = fs;     % Sampling frequency
signal.fc          = fc;     % Carrier frequency
signal.duration    = T;      % Signal duration
signal.Baud        = Baud;   % Baud rate
noise.gsnr         = GSNR;   % Generalized signal-to-noise ratio
noise.alpha        = alpha;  % Characteristic exponent
iter.cycle         = cycle;  % Number of samples

signal.M_ary       = M;
signal.dt          = 1/signal.fs;
signal.length      = signal.duration/ signal.dt;
signal.t           = 0: signal.dt: signal.duration-signal.dt;
signal.noise_cycle = zeros(iter.cycle,1024); 

for cnt = 1:iter.cycle
    %% Baseband Signal Generation
    signal.baseband = randi([0,signal.M_ary-1],1,signal.duration*signal.Baud);
    signal.basebandsample = reshape( repmat(signal.baseband, signal.fs/signal.Baud, 1), 1, length(signal.baseband)*signal.fs/signal.Baud );
    signal.basedbandmapping = pammod(signal.basebandsample, signal.M_ary);
    %% Passband Signal Generation
    signal.passband = real(signal.basedbandmapping).*cos (2 *pi *signal.fc *signal.t);
    signal.passband  = signal.passband/max(abs(signal.passband));
    signal.passband_used = signal.passband(1:signal.length_used); 
    signal.power = mean(signal.passband_used.^2);
    %% Rician Channel
    ricianChan = comm.RicianChannel(...
        'SampleRate',signal.fs, ...
        'PathDelays',[0 1e-4], ... 
        'AveragePathGains',[0 -3], ... 
        'NormalizePathGains',true, ... 
        'MaximumDopplerShift',50); 
    signal.passband_RicianChannel = ricianChan(signal.passband_used');
    %% Gaussian Noise
    signal.passband_gaussiannoise = awgn(signal.passband_RicianChannel', noise.gsnr); 
    %% Alpha-stable Noise 
    noise.true = 1;
    noise.beta = 0;  noise.delta = 0;
    noise.gamma = ( signal.power/ 10^(noise.gsnr/10) )^(1/noise.alpha);
    noise.real = Func_StableRnd(noise.alpha, noise.beta, noise.gamma, noise.delta, 1,signal.length_used);
    noise.imag = Func_StableRnd(noise.alpha, noise.beta, noise.gamma, noise.delta, 1,signal.length_used);
    noise.rnd = noise.real + 1i* noise.imag;
    noise.signal = signal.passband_gaussiannoise + noise.true * noise.rnd ;    
    %% 
    signal.noise_cycle(cnt,:) = noise.signal;
end
SNC_PAM4 = signal.noise_cycle;
save(['./signal/PAM4 alpha = ',num2str(noise.alpha*10),' GSNR = ',num2str(noise.gsnr),'.mat'],'SNC_PAM4')
toc
    