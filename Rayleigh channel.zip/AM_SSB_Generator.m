%  Signal Processing [SP]
%  Generate AM-SSB modulated signals with rayleigh channel and mixed noise
%  File: AM-SSB_Generator.m created by MATLAB 2019a
%  Last Revised: v 1.0    Date: 2021/12/05
%  Created: 2021/12/05
%  Author:  Shengyang Luan
%  Email:  luan@jsnu.edu.cn
%  (C)  School of Electrical Engineering and Automation
%       Jiangsu Normal University

function SNC_AM_SSB = AM_SSB_Generator(fc,fs,T,GSNR,alpha,cycle)
tic
%% Basic Parameters
signal.length_used = 1024;
signal.fs          = fs;      % Sampling frequency
signal.fc          = fc;      % Carrier frequency
signal.duration    = T;       % Signal duration
noise.gsnr         = GSNR;    % Generalized signal-to-noise ratio
noise.alpha        = alpha;   % Characteristic exponent
iter.cycle         = cycle;   % Number of samples

signal.dt          = 1/signal.fs; 
signal.N           = signal.duration/ signal.dt;
signal.t           = 0: signal.dt: signal.duration-signal.dt; 
signal.noise_cycle = zeros(iter.cycle,1024); 

for cnt = 1:iter.cycle
    %% Baseband Signal Generation
    signal.baseband = 5 + unifrnd(-5,5,1,signal.N);
    %% Passband Signal Generation
    signal.passband = modulate(signal.baseband, signal.fc, 1/signal.dt,'amssb');
    signal.passband = signal.passband/max(abs(signal.passband));
    signal.passband_used = signal.passband(1:signal.length_used); 
    signal.power = mean(signal.passband_used.^2);
    %% RayleighChannel
    rayleighchan = comm.RayleighChannel(...
        'SampleRate',signal.fs, ... 
        'PathDelays',[0 1e-4], ... 
        'AveragePathGains',[0 -3], ... 
        'NormalizePathGains',true, ...
        'MaximumDopplerShift',50); 
    signal.passband_RayleighChannel = rayleighchan(signal.passband_used'); 
    %% Gaussian Noise
    signal.passband_gaussiannoise = awgn(signal.passband_RayleighChannel', noise.gsnr); 
    %% Alpha-stable Noise 
    noise.true = 1;
    noise.beta = 0;  noise.delta = 0;
    noise.gamma = ( signal.power/ 10^(noise.gsnr/10) )^(1/noise.alpha);
    noise.real = Func_StableRnd(noise.alpha, noise.beta, noise.gamma, noise.delta, 1,signal.length_used);
    noise.imag = Func_StableRnd(noise.alpha, noise.beta, noise.gamma, noise.delta, 1,signal.length_used);
    noise.rnd = noise.real + 1i* noise.imag;
    noise.signal = signal.passband_gaussiannoise + noise.true * noise.rnd ;    
    %% 
    signal.noise_cycle(cnt,:) = noise.signal;
end
SNC_AM_SSB = signal.noise_cycle;
save(['./signal/AM_SSB alpha = ',num2str(noise.alpha*10),' GSNR = ',num2str(noise.gsnr),'.mat'],'SNC_AM_SSB');

toc