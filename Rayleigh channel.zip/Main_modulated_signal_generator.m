%  Signal Processing [SP]
%  Generate modulated signals with rayleigh channel and mixed noise
%  File: Main_modulated_signal_generator.m created by MATLAB 2019a
%  Last Revised: v 1.0    Date: 2021/12/05
%  Created: 2021/12/05
%  Author:  Shengyang Luan
%  Email:  luan@jsnu.edu.cn
%  (C)  School of Electrical Engineering and Automation
%       Jiangsu Normal University

clear; clc; close all;
%% Parameter Setting
lambda1  = 4;              % Set the scalor between Baud and fc
lambda2  = 10;             % Set the scalor between fs and fc
Baud     = 50;             % Baud rate
fc       = lambda1 * Baud; % Carrier frequency
fs       = lambda2 * fc;   % Sampling frequency
T        = 2;              % Signal duration
cycle    = 1000;           % Number of samples

%% Modulated Signal Generating
for GSNR = -20:2:20
    for alpha = 1.5
        GSNR
        alpha    
        %% AM_DSB
        AM_DSB_Generator(fc,fs,T,GSNR,alpha,cycle);

        %% AM_SSB
        AM_SSB_Generator(fc,fs,T,GSNR,alpha,cycle);
        
        %% WBFM 
        WBFM_Generator(fc,fs,T,GSNR,alpha,cycle);
        
        %% CPFSK
        CPFSK_Generator(fc,fs,Baud,T,GSNR,alpha,cycle);

        %% GFSK 
        GFSK_Generator(fc,fs,Baud,T,GSNR,alpha,cycle);
  
        %% BPSK 
        M = 2 ;
        BPSK_Generator(fc,fs,Baud,T,M,GSNR,alpha,cycle);
        
        %% QPSK 
        M = 4 ;
        QPSK_Generator(fc,fs,Baud,T,M,GSNR,alpha,cycle);
        
        %% PSK8
        M = 8 ;
        PSK8_Generator(fc,fs,Baud,T,M,GSNR,alpha,cycle);
        
        %% PAM4 
        M = 4 ;
        PAM4_Generator(fc,fs,Baud,T,M,GSNR,alpha,cycle);
        
        %% QAM16
        M = 16 ;
        QAM16_Generator(fc,fs,Baud,T,M,GSNR,alpha,cycle);
        
        %% QAM64 
        M = 64 ;
        QAM64_Generator(fc,fs,Baud,T,M,GSNR,alpha,cycle);
        

    end
end


